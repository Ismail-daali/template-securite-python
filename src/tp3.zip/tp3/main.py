import argparse
from pathlib import Path

import requests

from src.tp3.utils.config import logger, snapshot_082462
from src.tp3.utils.session import Session, run_network


def find_endpoint(target):
    """
    Fuzz les endpoints à partir de la wordlist pour trouver la page cachée.
    """
    with open(Path(__file__).parent / "wordlist.txt", "r", encoding="utf-8") as fichier:
        mots = [ligne.strip() for ligne in fichier if ligne.strip()]

    for mot in mots:
        url = target + "/" + mot
        try:
            reponse = requests.get(url, timeout=5)
        except requests.RequestException:
            continue

        if reponse.status_code == 200 and "captcha" in reponse.text.lower():
            logger.info(f"Endpoint trouvé : {url}")
            return url

    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True)
    args = parser.parse_args()

    snapshot_082462(args.target)
    logger.info("Starting TP3")

    target = args.target.rstrip("/")

    url = find_endpoint(target)
    if url is None:
        logger.error("Aucun endpoint trouvé")
        return

    session = Session(url)
    essais = 0

    while True:
        session.prepare_request()
        session.submit_request()

        if session.process_response():
            break

        essais += 1
        if essais > 30:
            logger.error("Captcha non résolu")
            return

    logger.info("Smell good !")
    logger.info(f"Flag for {url} : {session.get_flag()}")
    print(f"[+] FLAG1: {session.get_flag()}")

    if not session.host or not session.key:
        logger.error("Host ou clé introuvable")
        return

    drapeau_final = run_network(session.host, session.port, session.key.encode())
    print(f"[+] FLAG_FINAL: {drapeau_final}")


if __name__ == "__main__":
    main()